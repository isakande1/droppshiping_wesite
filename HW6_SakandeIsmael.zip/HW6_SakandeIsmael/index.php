<!DOCTYPE html >
<html>
<head>
  <title>Main Page </title>  
  <style>
    .di{
      display : grid;
      grid-template-columns : 1fr 1fr 1fr 1fr 1fr;
      grid-row-gap : 40px;
      column-gap : 20px;
    }
    .product{
      border-width : thin;
      border-color:blanchedalmond;
      border-style: solid;
      min-height: 200px;
    }
    .pname{
      text-align : left;
    }
    
   
   input[type="image"]{
      margin : auto auto auto;
      width: 50%;
      object-fit: contain;
    }
  </style>
</head>
<body>

  <div class ="di">
<?php
$cnx = new mysqli("localhost","root", "12345678", "dropshiping");
if ($cnx->connect_error)
   die('connnection failed' . $cnx->connect_error);
  
$query = "select *from products";
$cursor = $cnx->query($query);
while ($row = $cursor->fetch_assoc()){

  echo "<div class = 'product'> <p class= 'pname'> {$row['name']} </p>
  <form action='/compare.php' method='post' target ='_blank' > 
   <input type='image' src = '{$row['img_url']}' > 
   <input type='hidden' name='id' value= '{$row['id']}' />
   </form> </div>
  ";
}
$cnx->close();
?>
  </div>
</body>
</html>