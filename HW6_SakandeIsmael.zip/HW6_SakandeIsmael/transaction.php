<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title> Transaction </title>
    <style>
        form{
            margin : 0 auto;
        }
        
    </style>
</head>
<body>
    <?php
       if (!isset($_POST['card'] ) )  
         $_SESSION['sname'] = $_POST['pname'];
     ?>
    <form action="" method = "POST" target="_self">
       <p> <input type = "text" placeholder = "Name" name ='name'> </p>
        <p> <input type = "text" placeholder = "Address" name = 'address'></p>
       <p> <input type = "number" placeholder = "Credit card number" name ='card'></p>
       <p> <input type = "submit" value = "Confirm" > </p>
    </form>
    <?php
    if(isset($_POST['card'])){
     $cnx = new mysqli('localhost', 'root','12345678', 'dropshiping');
    if($cnx->connect_error)
       die('connection failed' . $cnx->connect_error);
    $query = "insert into transactions (customer_name, customer_address, credit_card_number,item_purchased) 
    values('{$_POST['name']}', '{$_POST['address']}', '{$_POST['card']}','{$_SESSION['sname']}');";
    $cnx->query($query);
    $cnx->close();
}

    ?>
</body>
</html>
