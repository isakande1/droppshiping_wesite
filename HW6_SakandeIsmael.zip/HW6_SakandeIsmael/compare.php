<!DOCTYPE html>
<html>
   <header> 
      <title> compare </title>
      <style>
         .template{
            display: grid;
            grid-template-columns: 250px 250px;
            column-gap : 40px;

         }
         .pname,.pdescription{
          text-align : left;
         }
         .image{
            margin : auto auto auto;
            width: 75%;
            object-fit: contain;
        }
        .price_review{
         display : grid;
         grid-template-columns: 50px 1fr;
         column-gap: 8px;
        }
       </style>
</header>  
<body>
   <div  class='template'>
<?php
$cnx = new mysqli('localhost', 'root','12345678','dropshiping');
$column = $_POST['id'];
$review ="No reviews";
$best_price=0;
$priceleft = 0;
$priceright = 0;
$id = 0;
$price ="";

for($x = 0; $x < 2; $x++){
if($cnx->connect_error  )
   die ('connection failed: ' . $cnx->connect_error);
   $query = "select *from products where id = $column";
   $cursor = $cnx->query($query);
   if($cnx->connect_error )
   die("connexion error" . $cnx->connect_error);
   while($row = $cursor->fetch_assoc()){
      if (strcmp($row['review_score'],"-1") != 0 ){
         $review = "Review score: " . $row['review_score'];
      }
      $price = "$" . number_format($row['price'] + ($row['price'] * 0.25),2);
      echo " <div id='id$x'> <p class='pname'> {$row['name']} </p>
      <div> <img class='image' src='{$row['img_url']}' > </div>
      <div class='price_review'> <p > $price </p> <p > $review </p> </div>
      <p class='pdescription'> {$row['description']}  </p>
      <form action='/transaction.php' target='_blank' method='POST'>
        <input type='hidden' name='pname' value= '{$row['name']}' />
          <input type='submit' value='Buy' >
      </form>
</div>";
   if ($_POST['id'] < 26)
     $column = ($_POST['id'] + 25) ;
   else if ($_POST['id'] > 25)
      $column =  ($_POST['id'] - 25 );
      
   if ($x == 0)
      $priceleft = $row['price'];
   else 
      $priceright = $row['price'];
   
   }
}

$cnx->close();
if( $priceleft > $priceright)
   $id = 1;

echo "<style> 
      #id$id{
         border-style: solid;
         border-width : 2px;
         border-color: yellow;
         
      }
     </style>"
?>
</div>
</body>
</html>