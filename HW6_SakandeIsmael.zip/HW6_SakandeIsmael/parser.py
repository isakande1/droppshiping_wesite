import sys
import xml.dom.minidom as dom
import mysql.connector as sql

fname = sys.argv[1]
id = int(sys.argv[2])
runs = sys.argv[3]
info = ["","","","","-1"]
def zappos():
    doc = dom.parse(fname)
    #print(fname)
    nodelist = doc.getElementsByTagName("span")
    for node in nodelist:
        #product name
        if node.getAttribute("class") == "bC-z":
            info[0] = (node.firstChild.nodeValue)
        #price
        elif  node.getAttribute("itemprop") == "price" :
            info[2] = (node.getAttribute("aria-label").strip("$"))
        #review
        elif  node.getAttribute("class") == "OT-z XE-z":
            info[4] = (node.getAttribute("data-star-rating"))

    #product description
    nodelist = doc.getElementsByTagName("li")
    for node in nodelist:
        if node.firstChild.nodeValue is not None:
           info[1]+= node.firstChild.nodeValue.replace("\n","")

    #picture
    nodelist = doc.getElementsByTagName("picture")
    for node in  nodelist[0].getElementsByTagName("img"):
        info[3]=(node.getAttribute("src"))
    #print(info)

#zappos()

def venus():
    doc = dom.parse(fname)
    #name
    nodelist = doc.getElementsByTagName("h1")
    for node in nodelist:
        if node.getAttribute("class") == "prodinfo-productname-h1" and node.hasChildNodes():
            info[0] = node.firstChild.nodeValue
            break
    #description
    nodelist = doc.getElementsByTagName("span")
    for node in nodelist:
        if node.getAttribute("class") == "viewproduct-accordionmaindescription-span":
            info[1] = node.childNodes[0].nodeValue
        #price
        elif   (node.getAttribute("class") == "prodinfo-price-span" or node.getAttribute("class") == "prodinfo-saleprice-span prodinfo-saleprice-span-nopadding") :
            if len(node.childNodes[0].nodeValue.replace("\n"," ").strip(" ").strip("$")) != 0:
               info[2] = node.childNodes[0].nodeValue.replace("\n"," ").strip(" ").strip("$")

    #picture
    nodelist = doc.getElementsByTagName("picture")
    for node in  nodelist[0].getElementsByTagName("img"):
        info[3]=(node.getAttribute("src"))

    #review
    nodelist = doc.getElementsByTagName("script")
    for node in nodelist:
        #print(node.getAttribute("div"))
        if node.getAttribute("type") == "application/ld+json":
            info[4] = node.firstChild.nodeValue.split()[10].strip(",").strip("\"")
            break

    #print(info)
#venus()

#database
tname = fname[:fname.index(".")]

print(tname)
def insert(cursor):
    query = "insert into products (vendor, name, description, price, img_url, review_score) values(%s,%s,%s,%s,%s,%s)"
    print(query)
    cursor.execute(query,(tname,info[0],info[1],info[2],info[3],info[4]))
def update(cursor):
    query = "update products set  vendor = %s, name = %s,  description = %s, price = %s, img_url = %s, review_score = %s where id = %s"
    cursor.execute(query,( tname, info[0],info[1],info[2],info[3],info[4], id))
def runsql():
    try:
        cnx = sql.connect(host = 'localhost', user = 'root', password ='12345678', database = 'dropshiping')
        cursor = cnx.cursor()     
        if runs == "0":
            insert(cursor)
        else:
            update(cursor)
        cnx.commit()
        cursor.close()  
    except sql.Error as err:
        print(err)
    finally :
        try:
            cnx
        except NameError:
            pass
        else:
            cnx.close()
            
if (tname == "venus"):
    venus()
    runsql()
else:
    zappos()
    runsql()
