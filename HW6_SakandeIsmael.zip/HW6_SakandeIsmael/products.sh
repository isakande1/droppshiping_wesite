#!/bin/bash
count=0
id=1
while :; do
for i in "${@}" ; do
fname="${i}.xhtml"
while read input; do
wget -O "${i}.html" -o /dev/null 2>& 1 "$input"
java -jar tagsoup-1.2.1.jar --files "./${i}.html" > /dev/null 2>& 1
python3 ./parser.py $fname $id $count > /dev/null
rm -r ./"${i}."?html
(( id++ ))
done < "./${i}"
done
rm -r ./*html*
sleep "6h"
id=1;
count=1
done
